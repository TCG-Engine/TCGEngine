120 transparent PNG frames, 512x512. Play at 15 fps for an eight-second loop. Frame 119 advances to frame 000. The trunk is fixed; foliage layers undergo rigid rotations only.
